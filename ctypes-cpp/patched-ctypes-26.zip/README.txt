This zipfile contains a patched _ctypes.pyd extension module
for Python 2.6 (Windows) that supports the __thiscall calling
convention.

Installation:
  _ctypes.pyd should go into the Python26\DLLs folder,
  __init__.py should go into the Python26\Lib\ctypes\ folder,


Be sure to save the original files so that you can revert this action.

Test that it works start python.exe, and run:

>>> import ctypes
>>> print ctypes.CPPDLL
<class 'ctypes.CPPDLL'>
>>>
